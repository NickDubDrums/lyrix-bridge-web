export const DEFAULT_PREFS = {
  performance: {
    stageBg: '#101014',
    // NEW: blocchi separati
    lyrics: {
      lineColor: '#f2f2f2',
      currentLineColor: '#ffffff',
      lineSizePct: 100,         // -> --lyrics-secondary-scale
      currentLineSizePct: 108,  // -> --lyrics-current-scale
    },
    chords: {
      lineColor: '#f2f2f2',
      currentLineColor: '#ffffff',
      lineSizePct: 100,         // -> --chords-secondary-scale
      currentLineSizePct: 106,  // -> --chords-current-scale
    },
    // Section / Title (opzionali)
    sectionColor: '#b8c1ff',
    titleColor: '#eaeaea',
    sectionSizePct: 90,
    titleSizePct: 90,
   },
   setlist: {
     playOnClick: false,
     dblClickOpensEditor: false,
     lockOnStart: false,
   },
 };