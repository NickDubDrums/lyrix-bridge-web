// === Stato client ===
const state = {
  ws: null,
  connected: false,
  // contenuti
  setlist: [],
  currentSongId: null,
  lyrics: ["(incolla il testo in EDITOR)"],
  currentLyricIndex: 0,
  chordTimeline: [],
  currentChordIndex: -1,
  chordNow: "—",
  transpose: Number(localStorage.getItem("transpose") || 0),
  // preferenze (CSS custom properties)
  prefs: {
    lyricsBg: localStorage.getItem("lyricsBg") || "#000000",
    lyricsFg: localStorage.getItem("lyricsFg") || "#ffffff",
    lyricsHi: localStorage.getItem("lyricsHi") || "#67e8f9",
    lyricsAlpha: Number(localStorage.getItem("lyricsAlpha") || 16),
    lyricsFont: Number(localStorage.getItem("lyricsFont") || 64),
    lyricsDim:  Number(localStorage.getItem("lyricsDim")  || 40),
    chordsBg: localStorage.getItem("chordsBg") || "#0b0b0e",
    chordsFg: localStorage.getItem("chordsFg") || "#f2f2f2",
    chordsHi: localStorage.getItem("chordsHi") || "#67e8f9",
    chordsAlpha: Number(localStorage.getItem("chordsAlpha") || 12),
    chordsNowFont: Number(localStorage.getItem("chordsNowFont") || 64),
    chordsNextFont: Number(localStorage.getItem("chordsNextFont") || 22),
  }
};

// === Utilità accordi: trasposizione semplice tonica ===
const NOTES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
function transposeSymbol(sym, semi) {
  if (!sym || sym === "—" || sym === "?") return sym;
  const m = String(sym).match(/^([A-G](?:#|b)?)(.*)$/);
  if (!m) return sym;
  const enh = { "Db":"C#", "Eb":"D#", "Gb":"F#", "Ab":"G#", "Bb":"A#" };
  const rootSharp = enh[m[1]] || m[1];
  const idx = NOTES.indexOf(rootSharp);
  if (idx < 0) return sym;
  let n = (idx + semi) % 12; if (n < 0) n += 12;
  return NOTES[n] + m[2];
}

// === DOM refs ===
const wsDot = document.getElementById("ws-dot");
const wsText = document.getElementById("ws-text");
const tabs = document.querySelectorAll(".tab");
const panels = document.querySelectorAll(".panel");

const lyricsStage = document.getElementById("lyricsStage");
const lyricsList = document.getElementById("lyricsList");

const chordNowEl = document.getElementById("chordNow");
const chordNextEl = document.getElementById("chordNext");

const lyricsInput = document.getElementById("lyricsInput");
const applyLyricsBtn = document.getElementById("applyLyrics");
const chordTimelineInput = document.getElementById("chordTimelineInput");
const applyTimelineBtn = document.getElementById("applyTimeline");

const setlistContainer = document.getElementById("setlistContainer");
const mockSetlistBtn = document.getElementById("mockSetlist");
const clearSetlistBtn = document.getElementById("clearSetlist");

const transpose = document.getElementById("transpose");
const transposeValue = document.getElementById("transposeValue");

// prefs controls
const lyBg = document.getElementById("lyBg");
const lyFg = document.getElementById("lyFg");
const lyHi = document.getElementById("lyHi");
const lyAlpha = document.getElementById("lyAlpha");
const lyFont = document.getElementById("lyFont");
const lyDim = document.getElementById("lyDim");

const chBg = document.getElementById("chBg");
const chFg = document.getElementById("chFg");
const chHi = document.getElementById("chHi");
const chAlpha = document.getElementById("chAlpha");
const chNowFont = document.getElementById("chNowFont");
const chNextFont = document.getElementById("chNextFont");

const savePrefsBtn = document.getElementById("savePrefs");
const resetPrefsBtn = document.getElementById("resetPrefs");

// === WebSocket connect ===
function connectWS() {
  const url = `ws://${location.host}/sync`;
  state.ws = new WebSocket(url);

  state.ws.addEventListener("open", () => {
    state.connected = true;
    wsDot.classList.remove("red"); wsDot.classList.add("green");
    wsText.textContent = "WS: connected";
  });
  state.ws.addEventListener("close", () => {
    state.connected = false;
    wsDot.classList.remove("green"); wsDot.classList.add("red");
    wsText.textContent = "WS: disconnected";
    setTimeout(connectWS, 1000);
  });
  state.ws.addEventListener("message", (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.type === "state") {
      const s = msg.state || {};
      // setlist “light”
      state.setlist = Array.isArray(s.setlist) ? s.setlist : [];
      state.currentSongId = s.currentSongId || null;

      // contenuti brano corrente
      if (s.currentSong) {
        state.lyrics = s.currentSong.lyrics || [];
        state.chordTimeline = s.currentSong.chordTimeline || [];
      }

      state.currentLyricIndex = Number.isInteger(s.lyricIndex) ? s.lyricIndex : 0;
      state.currentChordIndex = Number.isInteger(s.chordIndex) ? s.chordIndex : -1;
      state.chordNow = s.chordNow || "—";

      renderLyrics(true);
      renderChordNow();
      renderChordNext();
      renderSetlist();
      return;
    }

    if (msg.type === "lyric/next") {
      state.currentLyricIndex = Math.min(state.currentLyricIndex + 1, state.lyrics.length - 1);
      renderLyrics(true);
      if (state.chordTimeline.length) {
        state.currentChordIndex = Math.min(state.currentChordIndex + 1, state.chordTimeline.length - 1);
        updateChordsFromTimeline();
      }
    } else if (msg.type === "lyric/goto") {
      state.currentLyricIndex = Math.max(0, Math.min(Number(msg.index)||0, state.lyrics.length - 1));
      renderLyrics(true);
      if (state.chordTimeline.length) {
        state.currentChordIndex = state.currentLyricIndex;
        updateChordsFromTimeline();
      }
    } else if (msg.type === "chord") {
      state.chordNow = msg.symbol || "?";
      renderChordNow();
    } else if (msg.type === "song/selected") {
      // già gestito a livello di "state" successivo
    }
  });
}

// === Render Lyrics Karaoke ===
function renderLyrics(scrollToCurrent=false) {
  lyricsList.innerHTML = "";
  state.lyrics.forEach((line, i) => {
    const div = document.createElement("div");
    div.className = "line" + (i === state.currentLyricIndex ? " current" : "");
    div.textContent = line;
    lyricsList.appendChild(div);
  });

  if (scrollToCurrent) {
    const currentEl = lyricsList.querySelector(".line.current");
    if (currentEl) {
      // centra la riga corrente verticalmente nel box
      const stageRect = lyricsStage.getBoundingClientRect();
      const curRect = currentEl.getBoundingClientRect();
      const delta = (curRect.top + curRect.height/2) - (stageRect.top + stageRect.height/2);
      lyricsStage.scrollBy({ top: delta, behavior: "smooth" });
    }
  }
}

// === Render Chords ===
function renderChordNow() {
  chordNowEl.textContent = transposeSymbol(state.chordNow, state.transpose);
}
function renderChordNext() {
  chordNextEl.innerHTML = "";
  if (!state.chordTimeline.length) {
    chordNextEl.innerHTML = `<div class="cell">—</div><div class="cell">—</div><div class="cell">—</div><div class="cell">—</div>`;
    return;
  }
  const i = state.currentChordIndex;
  const next = state.chordTimeline.slice(i + 1, i + 5);
  for (let k = 0; k < 4; k++) {
    const sym = next[k] || "—";
    const cell = document.createElement("div");
    cell.className = "cell";
    cell.textContent = transposeSymbol(sym, state.transpose);
    chordNextEl.appendChild(cell);
  }
}
function updateChordsFromTimeline() {
  const i = Math.max(0, Math.min(state.currentChordIndex, state.chordTimeline.length - 1));
  state.chordNow = state.chordTimeline[i] || state.chordNow;
  renderChordNow();
  renderChordNext();
}

// === SETLIST ===
function renderSetlist() {
  setlistContainer.innerHTML = "";
  state.setlist.forEach(s => {
    const card = document.createElement("div");
    card.className = "song" + (s.id === state.currentSongId ? " active" : "");
    const title = document.createElement("div");
    title.className = "title";
    title.textContent = s.title;
    const id = document.createElement("small");
    id.textContent = s.id;
    card.appendChild(title); card.appendChild(id);
    card.addEventListener("click", () => {
      // chiede al server di selezionare quel brano
      state.ws?.send(JSON.stringify({ type: "song/select", id: s.id }));
    });
    setlistContainer.appendChild(card);
  });
}

mockSetlistBtn?.addEventListener("click", () => {
  const mock = [
    { id: "song-1", title: "Intro", lyrics: ["Benvenuti","..."], chordTimeline: ["Em","D","G","C"] },
    { id: "song-2", title: "Fiume", lyrics: ["Scorri piano","tra le mani","..." ], chordTimeline: ["C","G","Am","F","C","G","Am","F"] },
    { id: "song-3", title: "Notte", lyrics: ["Sotto il cielo","blu scuro","..." ], chordTimeline: ["Dm","Bb","F","C"] }
  ];
  state.ws?.send(JSON.stringify({ type: "setlist/replace", setlist: mock }));
});

clearSetlistBtn?.addEventListener("click", () => {
  state.ws?.send(JSON.stringify({ type: "setlist/replace", setlist: [] }));
});

// === EDITOR actions ===
applyLyricsBtn.addEventListener("click", () => {
  const text = lyricsInput.value.trim();
  const newLyrics = text ? text.split(/\r?\n/) : ["(vuoto)"];
  const id = state.currentSongId || (state.setlist[0]?.id);
  if (!id) return alert("Nessun brano nella setlist");
  state.ws?.send(JSON.stringify({ type: "song/update", song: { id, lyrics: newLyrics } }));
});

applyTimelineBtn.addEventListener("click", () => {
  const list = chordTimelineInput.value.trim().split(/\s+/).filter(Boolean);
  const id = state.currentSongId || (state.setlist[0]?.id);
  if (!id) return alert("Nessun brano nella setlist");
  state.ws?.send(JSON.stringify({ type: "song/update", song: { id, chordTimeline: list } }));
});

// === Tabs ===
tabs.forEach((btn) => {
  btn.addEventListener("click", () => {
    tabs.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    panels.forEach(p => p.classList.remove("show"));
    document.getElementById(btn.dataset.tab).classList.add("show");
  });
});

// === Transpose ===
transpose.value = state.transpose;
transposeValue.textContent = state.transpose;
transpose.addEventListener("input", () => {
  state.transpose = Number(transpose.value);
  transposeValue.textContent = state.transpose;
  localStorage.setItem("transpose", String(state.transpose));
  renderChordNow();
  renderChordNext();
});

// === Prefs: applica ai CSS custom properties ===
function applyPrefs() {
  const r = document.documentElement.style;
  const p = state.prefs;

  r.setProperty("--lyrics-bg", p.lyricsBg);
  r.setProperty("--lyrics-fg", p.lyricsFg);
  r.setProperty("--lyrics-hi", p.lyricsHi);
  r.setProperty("--lyrics-alpha", p.lyricsAlpha);
  r.setProperty("--lyrics-font", p.lyricsFont);
  r.setProperty("--lyrics-dim", p.lyricsDim);

  r.setProperty("--chords-bg", p.chordsBg);
  r.setProperty("--chords-fg", p.chordsFg);
  r.setProperty("--chords-hi", p.chordsHi);
  r.setProperty("--chords-alpha", p.chordsAlpha);
  r.setProperty("--chords-now-font", p.chordsNowFont);
  r.setProperty("--chords-next-font", p.chordsNextFont);
}

// bind controlli editor ↔ prefs
function initPrefsControls() {
  const p = state.prefs;
  lyBg.value = p.lyricsBg; lyFg.value = p.lyricsFg; lyHi.value = p.lyricsHi;
  lyAlpha.value = p.lyricsAlpha; lyFont.value = p.lyricsFont; lyDim.value = p.lyricsDim;
  chBg.value = p.chordsBg; chFg.value = p.chordsFg; chHi.value = p.chordsHi;
  chAlpha.value = p.chordsAlpha; chNowFont.value = p.chordsNowFont; chNextFont.value = p.chordsNextFont;

  const bind = (el, key, transform=(v)=>v) => {
    el.addEventListener("input", () => {
      state.prefs[key] = transform(el.value);
      applyPrefs();
    });
  };
  bind(lyBg, "lyricsBg"); bind(lyFg, "lyricsFg"); bind(lyHi, "lyricsHi");
  bind(lyAlpha, "lyricsAlpha", Number); bind(lyFont, "lyricsFont", Number); bind(lyDim, "lyricsDim", Number);
  bind(chBg, "chordsBg"); bind(chFg, "chordsFg"); bind(chHi, "chordsHi");
  bind(chAlpha, "chordsAlpha", Number); bind(chNowFont, "chordsNowFont", Number); bind(chNextFont, "chordsNextFont", Number);

  savePrefsBtn.addEventListener("click", () => {
    Object.entries(state.prefs).forEach(([k,v]) => localStorage.setItem(k, String(v)));
    alert("Preferenze salvate su questo dispositivo");
  });
  resetPrefsBtn.addEventListener("click", () => {
    localStorage.removeItem("lyricsBg"); localStorage.removeItem("lyricsFg"); localStorage.removeItem("lyricsHi");
    localStorage.removeItem("lyricsAlpha"); localStorage.removeItem("lyricsFont"); localStorage.removeItem("lyricsDim");
    localStorage.removeItem("chordsBg"); localStorage.removeItem("chordsFg"); localStorage.removeItem("chordsHi");
    localStorage.removeItem("chordsAlpha"); localStorage.removeItem("chordsNowFont"); localStorage.removeItem("chordsNextFont");
    // defaults
    state.prefs = {
      lyricsBg:"#000000", lyricsFg:"#ffffff", lyricsHi:"#67e8f9", lyricsAlpha:16, lyricsFont:64, lyricsDim:40,
      chordsBg:"#0b0b0e", chordsFg:"#f2f2f2", chordsHi:"#67e8f9", chordsAlpha:12, chordsNowFont:64, chordsNextFont:22,
    };
    initPrefsControls();
    applyPrefs();
  });
}

// === Boot ===
applyPrefs();
initPrefsControls();
connectWS();

// Demo iniziale (se il server non ha ancora stato)
if (!state.lyrics?.length) state.lyrics = ["Prima riga","Seconda riga","Terza riga","Quarta riga"];
renderLyrics(true);
renderChordNow();
renderChordNext();
